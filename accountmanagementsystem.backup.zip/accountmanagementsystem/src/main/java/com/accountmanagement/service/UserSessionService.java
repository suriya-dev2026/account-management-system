package com.accountmanagement.service;

import com.accountmanagement.repository.UserSessionRepository;
import com.accountmanagement.utility.TokenUtility;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accountmanagement.exceptions.RecordNotFoundException;
import com.accountmanagement.model.UserSession;

@Service
public class UserSessionService {

    @Autowired
    private UserSessionRepository userSessionRepository;

    @Autowired
    private TokenUtility tokenUtility;

    public UserSession createUserSession(String userId, String otp) {
        UserSession userSession = new UserSession(); 
        userSession.setUserId(userId);
        userSession.setOtp(otp);
        userSession.setOtpExpiration(LocalDateTime.now().plusMinutes(2));
        userSession.setOtpVerificationCount(0);
        userSession.setIsOtpVerified(false);
        userSession.setRefreshKeyStatus(true);
        userSession.setSessionStatus("Active");
        userSession.setIsValidAccessToken(true);
        return userSessionRepository.save(userSession);
    }

    public void updateSessionAfterOtp(String userId, String refreshKey) {
        UserSession session = userSessionRepository.findTopByUserIdOrderByCreatedAtDesc(userId);
        if (session == null) {
            throw new RecordNotFoundException("user not found");
        }
        session.setRefreshKey(refreshKey);
        session.setRefreshKeyCreatedAt(LocalDateTime.now());
        session.setRefreshKeyExpiration(LocalDateTime.now().plusHours(24));
        session.setIsOtpVerified(true);
        session.setOtp(null);
        userSessionRepository.save(session);
    }

    public UserSession findRefreshKey(String refreshKey) {
        UserSession userSession = userSessionRepository.findByRefreshKey(refreshKey);
        if (userSession.getRefreshKey() == null) {
            throw new RecordNotFoundException("Refresh key not found");
        }
        return userSession;
    }
}
